//
//  IDViewController.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 9.12.20..
//

import UIKit

class IDViewController: UIViewController {

    @IBOutlet weak var ivLogo: UIImageView!
    @IBOutlet weak var ivUser: UIImageView!
    @IBOutlet weak var ivVendor: UIImageView!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelUser: UILabel!
    
    public var discount: Discount!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        ivLogo.clipsToBounds = true
        ivLogo.layer.masksToBounds = true
        ivLogo.layer.cornerRadius = ivLogo.bounds.width / 2
        ivLogo.layer.borderWidth = 0.5
        ivLogo.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor

        ivUser.clipsToBounds = true
        ivUser.layer.masksToBounds = true
        ivUser.layer.cornerRadius = ivUser.bounds.width / 2
        ivUser.layer.borderWidth = 0.5
        ivUser.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor

        ivVendor.clipsToBounds = true
        ivVendor.layer.masksToBounds = true
        ivVendor.layer.cornerRadius = ivVendor.bounds.width / 2
        ivVendor.layer.borderWidth = 0.5
        ivVendor.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor

        ivVendor.sd_setImage(with: URL(string: APIManager.urlImage + discount.vendorPhoto!), completed: nil)
        
        if let photo = DataManager.currentUser?.photo {
            ivUser.sd_setImage(with: URL(string: APIManager.urlImage + photo), completed: nil)
        }
        
        labelTitle.text = discount.title
        labelUser.text = DataManager.currentUser?.name
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
