//
//  DataManager.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 7.12.20..
//

import UIKit
import Foundation

class DataManager {
    static let shared = DataManager()
    
    public static var categoryID = 0
    
    public static var currentUser: User?
    
    public static var categories: [Category] = []
    public static var discounts: [Discount] = []

    public static func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    public static func loadDatas(_ view: UIView, completion: @escaping () -> ()) {
        UIManager.shared.showHUD(view: view)
        APIManager.shared.getCategories { (success, categories, msg) in
            
            if success {
                self.categories = categories!
            } else {
                self.categories = []
                UIManager.shared.hideHUD()
                completion()
                return
            }
            
            APIManager.shared.getDiscounts("", 0) { (success, discounts, msg) in
                if success {
                    self.discounts = discounts!
                } else {
                    self.discounts = []
                }
                
                print(self.discounts)

                UIManager.shared.hideHUD()
                completion()
            }
        }
    }
}
