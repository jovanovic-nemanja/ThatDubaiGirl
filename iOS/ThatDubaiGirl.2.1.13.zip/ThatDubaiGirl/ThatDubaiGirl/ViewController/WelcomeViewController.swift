//
//  ViewController.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 7.12.20..
//

import UIKit

class WelcomeViewController: UIViewController {

    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnSignup: UIButton!
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        super.viewWillAppear(animated)
        
        if ((UserDefaults.standard.value(forKey: "email") != nil) && (UserDefaults.standard.value(forKey: "password") != nil)) {
            
            let email = UserDefaults.standard.value(forKey: "email") as! String
            let password = UserDefaults.standard.value(forKey: "password") as! String

            UIManager.shared.showHUD(view: self.view)
            
            APIManager.shared.login(email, password: password) { (success, user, message) in
                UIManager.shared.hideHUD()
                
                if (success) {
                    UserDefaults.standard.setValue(user?.email, forKey: "email")
                    UserDefaults.standard.setValue(password, forKey: "password")
                    DataManager.currentUser = user
                    
                    self.performSegue(withIdentifier: "home", sender: nil)
                } else {
                    UserDefaults.standard.removeObject(forKey: "email")
                    UserDefaults.standard.removeObject(forKey: "password")
                    DataManager.currentUser = nil

                    UIManager.shared.showAlert(vc: self, title: "Error", message: message!)
                    return
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        btnSignup.layer.borderColor = UIColor.white.cgColor
        btnSignup.layer.borderWidth = 1
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        super.viewWillDisappear(animated)
    }
    
    @IBAction func joinFacebook(_ sender: Any) {
        if let url = URL(string: "https://www.facebook.com/groups/thatdubaigirl/?ref=share") {
            UIApplication.shared.open(url)
        }
    }
    
    @IBAction func joinYoutube(_ sender: Any) {
        if let url = URL(string: "https://www.instagram.com/thatdubaigirl_/?hl=en"/*"https://youtu.be/VSo41Y9i2Ug"*/) {
            UIApplication.shared.open(url)
        }
    }
}
