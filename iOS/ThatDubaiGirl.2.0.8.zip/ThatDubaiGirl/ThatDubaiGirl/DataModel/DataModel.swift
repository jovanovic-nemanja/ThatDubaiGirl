//
//  DataModel.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 7.12.20..
//

import Foundation
import ObjectMapper

struct User: Mappable {
    var id: Int = 0
    var uniqueId: String?
    var name: String?
    var email: String?
    var photo: String?

    init?(map: Map) {
    }
    
    mutating func mapping(map: Map) {
        id <- map["id"]
        uniqueId <- map["userUniqueId"]
        name <- map["username"]
        email <- map["email"]
        photo <- map["photo"]
    }
}

struct Intro: Mappable {
    var data: String?
    var status: String?
    
    init?(map: Map) {
    }
    
    mutating func mapping(map: Map) {
        data <- map["data"]
        status <- map["status"]
    }
}

struct Vendor: Mappable {
    var id: String?
    var name: String?
    
    init?(map: Map) {
    }
    
    mutating func mapping(map: Map) {
        id <- map["id"]
        name <- map["vendorname"]
    }
}

struct Category: Mappable {
    var id: Int = -1
    var name: String = ""
    var photo: String = ""
    
    init?(map: Map) {
    }
    
    mutating func mapping(map: Map) {
        id <- map["id"]
        name <- map["category_name"]
        photo <- map["category_photo"]
    }
}

struct Discount: Mappable {
    var id: Int?
    var title: String?
    var photo: String?
    var description: String?
    var vendorName: String?
    var vendorPhone: String?
    var vendorPhoto: String?
    var location: String?

    init?(map: Map) {
    }
    
    mutating func mapping(map: Map) {
        id <- map["id"]
        title <- map["title"]
        photo <- map["discount_photo"]
        description <- map["description"]
        vendorName <- map["vendorname"]
        vendorPhone <- map["phone"]
        vendorPhoto <- map["photo"]
        location <- map["location"]
        
        if description!.count > 0 {
            description = description!.replacingOccurrences(of: "\r", with: " ")
            description = description!.replacingOccurrences(of: "\n", with: " ")
        }
    }
}
