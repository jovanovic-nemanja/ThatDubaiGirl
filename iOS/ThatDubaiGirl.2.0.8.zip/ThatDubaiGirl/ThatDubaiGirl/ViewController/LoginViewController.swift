//
//  LoginViewController.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 7.12.20..
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onLogin(_ sender: Any) {
        guard let email = tfEmail.text, !email.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "Error", message: "Please input e-mail address.")
            return
        }
        
        if (!isValidEmail(email)) {
            UIManager.shared.showAlert(vc: self, title: "Error", message: "Invalid e-mail address.")
            return
        }
        
        guard let password = tfPassword.text, !password.isEmpty else {
            UIManager.shared.showAlert(vc: self, title: "Error", message: "Please input your password.")
            return
        }
        
        UIManager.shared.showHUD(view: self.view)
        
        APIManager.shared.login(email, password: password) { (success, user, message) in
            UIManager.shared.hideHUD()
            
            if (success) {
                UserDefaults.standard.setValue(user?.email, forKey: "email")
                UserDefaults.standard.setValue(password, forKey: "password")
                DataManager.currentUser = user
                
                self.performSegue(withIdentifier: "video", sender: nil)
            } else {
                UIManager.shared.showAlert(vc: self, title: "Error", message: message!)
                return
            }
        }
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}
