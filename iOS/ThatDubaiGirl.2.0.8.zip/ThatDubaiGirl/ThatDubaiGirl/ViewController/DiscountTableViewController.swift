//
//  DiscountTableViewController.swift
//  ThatDubaiGirl
//
//  Created by Bozo Krkeljas on 8.12.20..
//

import UIKit
import SideMenu

class DiscountTableViewController: UITableViewController, UISearchResultsUpdating {
    private var prevCategoryID: Int = 0
    private var discounts: [Discount] = []
    private var filteredDiscounts: [Discount] = []
    
    var searchController = UISearchController()
    
    func updateSearchResults(for searchController: UISearchController) {
        filteredDiscounts.removeAll()
        
        let key = searchController.searchBar.text
        if (key?.count == 0) {
            filteredDiscounts = discounts.filter({ (Discount) -> Bool in
                return true
            })
        } else {
            for discount in discounts {
                if discount.vendorName!.contains(key!) {
                    filteredDiscounts.append(discount)
                }
            }
        }
        
        self.tableView.reloadData()
    }
    
    func updateData() {
        let categoryID = DataManager.categoryID
        
        UIManager.shared.showHUD(view: self.view)
        APIManager.shared.getDiscounts("", categoryID) { (success, discounts, msg) in
            UIManager.shared.hideHUD()
            if success {
                self.discounts = discounts!
                self.tableView.reloadData()
            } else {
                self.discounts = []
                self.tableView.reloadData()
            }
        }

        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchController = ({
            let controller = UISearchController(searchResultsController: nil)
            controller.searchResultsUpdater = self
            controller.searchBar.sizeToFit()
            controller.searchBar.placeholder = "Search by Vendor Name"
            controller.obscuresBackgroundDuringPresentation = false;
            
            tableView.tableHeaderView = controller.searchBar
            return controller
        })()
        
        self.tableView.tableFooterView = UIView()
        
        updateData()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if (searchController.isActive) {
            return filteredDiscounts.count
        }
        
        return self.discounts.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DiscountCell", for: indexPath) as! DiscountTableViewCell
        
        cell.ivImage.clipsToBounds = true
        cell.ivImage.layer.masksToBounds = true
        cell.ivImage.layer.cornerRadius = cell.ivImage.bounds.width / 2
        cell.ivImage.layer.borderWidth = 0.5
        cell.ivImage.layer.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor

        // Configure the cell...
        if (searchController.isActive) {
            cell.labelTitle.text = filteredDiscounts[indexPath.row].title
            cell.labelDetail.text = filteredDiscounts[indexPath.row].description
            cell.ivImage.sd_setImage(with: URL(string: APIManager.urlImage + filteredDiscounts[indexPath.row].photo!), completed: nil)
        } else {
            cell.labelTitle.text = discounts[indexPath.row].title
            cell.labelDetail.text = discounts[indexPath.row].description
            cell.ivImage.sd_setImage(with: URL(string: APIManager.urlImage + discounts[indexPath.row].photo!), completed: nil)
        }

        return cell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (self.searchController.isActive) {
            self.searchController.dismiss(animated: false) {
                self.searchController.isActive = false
                self.performSegue(withIdentifier: "detail", sender: self.filteredDiscounts[indexPath.row])
            }
        } else {
            self.performSegue(withIdentifier: "detail", sender: self.discounts[indexPath.row])
        }
    }

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "detail") {
            let discount = sender as! Discount
            if let vcDetail = segue.destination as? DetailViewController {
                vcDetail.discount = discount
            }
        }
    }

    @IBAction func onCategory(_ sender: Any) {
        if (searchController.isActive) {
            searchController.isActive = false
        }
        
        if (searchController.isEditing) {
            searchController.isEditing = false
        }
        
        let vcMenu = storyboard?.instantiateViewController(withIdentifier: "LeftMenu") as! SideMenuNavigationController
        vcMenu.presentationStyle = .menuSlideIn
        present(vcMenu, animated: true, completion: nil)
    }
    
    @IBAction func onLogout(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "email")
        UserDefaults.standard.removeObject(forKey: "password")
        DataManager.currentUser = nil
        
        self.navigationController?.popToRootViewController(animated: true)
    }
}

extension DiscountTableViewController: SideMenuNavigationControllerDelegate {
    func sideMenuWillAppear(menu: SideMenuNavigationController, animated: Bool) {
        print("SideMenu Appearing! (animated: \(animated))")
        
        prevCategoryID = DataManager.categoryID
    }

    func sideMenuDidAppear(menu: SideMenuNavigationController, animated: Bool) {
        print("SideMenu Appeared! (animated: \(animated))")
    }

    func sideMenuWillDisappear(menu: SideMenuNavigationController, animated: Bool) {
        print("SideMenu Disappearing! (animated: \(animated))")
    }

    func sideMenuDidDisappear(menu: SideMenuNavigationController, animated: Bool) {
        print("SideMenu Disappeared! (animated: \(animated))")

        if (DataManager.categoryID != prevCategoryID) {
            updateData()
        }
    }
}
